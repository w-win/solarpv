from django.apps import AppConfig


class SolarpvappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'solarpvapp'
