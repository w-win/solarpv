from django.urls import path
from . import views 


urlpatterns = [
	path('', views.index, name='Homepage'),
	path('Menu1/', views.Menu1, name='Menu1'),
	path('Register/', views.Register, name='Register'),
	path('Login/', views.login, name='Login'),
	path('search_certificate', views.search_certificate, name='search-certificate'),
	path('show_certificate/<certificate_id>', views.show_certificate, name='show-certificate'),
	path('list_certificate/', views.list_certificate, name='list-certificate'),
]