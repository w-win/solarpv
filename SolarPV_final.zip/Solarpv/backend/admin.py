from django.contrib import admin
from .models import service,product,certificate

admin.site.register(service)
admin.site.register(product)
admin.site.register(certificate)
# Register your models here.
