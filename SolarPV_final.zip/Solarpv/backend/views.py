from django.shortcuts import render
from rest_framework import viewsets
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm
from .models import service, product, certificate
from .serializers import serviceserializer
from .serializers import productserializer
from .serializers import certificateserializer


class serviceview(viewsets.ModelViewSet):
	queryset = service.objects.all()
	serializer_class = serviceserializer

class productview(viewsets.ModelViewSet):
	queryset = product.objects.all()
	serializer_class = productserializer

class certificateview(viewsets.ModelViewSet):
	queryset = certificate.objects.all()
	serializer_class = certificateserializer


