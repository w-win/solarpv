from django.shortcuts import render,redirect
from backend.models import certificate
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required


def registerPage(request):
	if request.user.is_authenticated:
		return redirect('home')
	else:
		form = CreateUserForm()
		if request.method == 'POST':
			form = CreateUserForm(request.POST)
			if form.is_valid():
				form.save()
				user = form.cleaned_data.get('username')
				messages.success(request, 'Account was created for ' + user)

				return redirect('login')
			

		context = {'form':form}
		return render(request, 'accounts/register.html', context)


def search_certificate(request):
	if request.method == "POST":
		searched = request.POST['searched']
		certs = certificate.objects.filter(certNumber__contains=searched,certID__contains=searched)


# certNumber__contains=searched, 
# 			certID__contains=searched,
# 			reportnumber__contains=searched,
# 			locationID__contains=searched,
# 			modelnumber_id__contains=searched,
# 			standardID__contains=searched, 
# 			userID__contains=searched)
			 
			
			

#     certNumber 
# 	certID 
# 	userID 
# 	reportnumber 
# 	standardID 
# 	locationID 
# 	modelnumber

# certNumber,certID,reportnumnber,locationID_id,modelnumber_id,standardID_id,userID_id


		return render(request,
		'solarpvapp/search_certificate.html',
		{'searched':searched,
		'certs':searched})
	else:
		return render(request,
			'solarpvapp/search_certificate.html',
		{})




def show_certificate(request, cert_id): 
	 certificate = certificate.objects.get(pk=certificate_id)
	 return render(request, 'solarpvapp/show_certificate.html',
	{'certificate':certificate})

def list_certificate(request):
	certificate_list = certificate.objects.all()
	return render(request, 'solarpvapp/certificate_list.html',
		{'certificate_list':certificate_list})



def show_certificate(request):
	return render(request, 'solarpvapp/show_certificate.html')

def index(request):
	return render(request, 'solarpvapp/Homepage.html')


def Menu1(request):
	return render(request, 'solarpvapp/Menu1.html')

def login(request):
    return render(request, 'solarpvapp/login.html')

def Register(request):
	return render(request, 'solarpvapp/registeration.html')


