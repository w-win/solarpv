from django.urls import path, include
from . import views 
from rest_framework import routers

router = routers.DefaultRouter()
router.register('service', views.serviceview),
router.register('product', views.productview),
router.register('certificate', views.certificateview)

# Serializers define the API representation.
urlpatterns = [ 
	path('', include(router.urls))

]



