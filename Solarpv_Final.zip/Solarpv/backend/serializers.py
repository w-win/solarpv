
from rest_framework import serializers
from .models import service, product, certificate

class serviceserializer(serializers.ModelSerializer):
    class Meta:
        model = service
        fields = '__all__'

class productserializer(serializers.ModelSerializer):
    class Meta:
        model = product
        fields = '__all__'


class certificateserializer(serializers.ModelSerializer):
    class Meta:
        model = certificate
        fields = '__all__'
         # fields = ('certNumber','certID','reportnumber','locationID_id','modelnumber_id','standardID_id','userID_id')