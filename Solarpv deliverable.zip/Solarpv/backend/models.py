from django.db import models

# Create your models here.




class client(models.Model):
	clientName = models.CharField(max_length=20)
	clientType = models.CharField(max_length=20)


class user(models.Model):
	first_name = models.CharField(max_length=20)
	last_name = models.CharField(max_length=20)
	middle_name = models.CharField(max_length=20)
	job_title = models.CharField(max_length=30)
	email = models.EmailField(max_length=50)
	ophone = models.CharField(max_length=20)
	cphone = models.CharField(max_length=20)
	user_client = models.ForeignKey(client, on_delete=models.CASCADE)


class location(models.Model):
	address1 = models.CharField(max_length=50)
	address2 = models.CharField(max_length=10)
	city = models.CharField(max_length=50)
	state = models.CharField(max_length=2)
	postalcode = models.IntegerField()
	country = models.CharField(max_length=50)
	pnumber = models.CharField(max_length=20)
	faxnumber = models.CharField(max_length=20)
	location_client = models.ForeignKey(client, on_delete=models.CASCADE)

class test_standard(models.Model):
	standardname = models.CharField(max_length=20)
	description = models.CharField(max_length=50)
	publishDate = models.DateTimeField()


class service(models.Model):
	serviceID = models.SmallAutoField(primary_key = True)
	servicename = models.CharField(max_length=20)
	description = models.CharField(max_length=50)
	is_FI_req = models.BooleanField(default=False, verbose_name="FI Require")
	FI_freq = models.CharField(max_length=20)
	standardID = models.ForeignKey(test_standard, on_delete=models.CASCADE)

class product(models.Model):
	modelnumber = models.IntegerField(primary_key=True)
	productname = models.CharField(max_length=20)
	celltechnology = models.CharField(max_length=20)
	cellmanufacturer = models.CharField(max_length=20)
	numofcells = models.IntegerField()
	numofcellsinser = models.IntegerField()
	numofcellstr = models.IntegerField()
	numofdio = models.IntegerField()
	productlength = models.CharField(max_length=20)
	productwidth = models.CharField(max_length=20)
	productweight = models.CharField(max_length=20)
	superstatetype = models.CharField(max_length=20)
	superstatemanu = models.CharField(max_length=20)
	substratetype = models.CharField(max_length=20)
	substratemanu = models.CharField(max_length=20)
	frametype = models.CharField(max_length=20)
	frameadhe = models.CharField(max_length=20)
	encaptype = models.CharField(max_length=20)
	encapmanu = models.CharField(max_length=20)
	junctboxtype = models.CharField(max_length=20)
	junctboxmanu = models.CharField(max_length=20)

class certificate(models.Model):
	certNumber = models.IntegerField(primary_key = True)
	certID = models.IntegerField()
	userID = models.ForeignKey(user, on_delete=models.CASCADE)
	reportnumber = models.IntegerField()
	standardID = models.ForeignKey(test_standard, on_delete=models.CASCADE)
	locationID = models.ForeignKey(location, on_delete=models.CASCADE)
	modelnumber = models.ForeignKey(product, on_delete=models.CASCADE)


class test_seq(models.Model):
	seqID = models.IntegerField(primary_key = True)
	seqname = models.CharField(max_length=20)

class perform_data(models.Model):
	modelnumber = models.ForeignKey(product, on_delete=models.CASCADE)
	seqID = models.ForeignKey(test_seq, on_delete=models.CASCADE)
	maxsysvol = models.CharField(max_length=20)
	voc = models.CharField(max_length=20)
	isc = models.CharField(max_length=20)
	vmp = models.CharField(max_length=20)
	imp = models.CharField(max_length=20)
	pmp = models.CharField(max_length=20)
	ft = models.CharField(max_length=20)